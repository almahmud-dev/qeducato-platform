"use client";

import { useRef, useEffect } from "react";
import Link from "next/link";
import gsap from "gsap";

export default function DirectionalButton({
  label,
  bgColor = "transparent",
  leftIcon,
  rightIcon,
  type = "button",
  disabled = false,
  borderColor = "#ff5101",
  borderHoverColor = null,
  flairColor = "#ff5101",
  textColor = "var(--text-primary)",
  textHoverColor = "#ffffff",
  shadowHover = "0 0 18px 2px #ff510133",
  size = "md",
  onClick,
  href,
  target,
  className = "",
  textTypo,
  ariaLabel,
}) {
  const btnRef = useRef(null);
  const flairRef = useRef(null);
  const labelRef = useRef(null);

  const sizeMap = {
    sm: "px-5 py-2 text-[13px] gap-1.5",
    md: "px-6 py-2 text-[14px] gap-2",
    lg: "px-7 py-3 text-base gap-2.5",
  };

  const sz = sizeMap[size] ?? sizeMap.md;
  const shadowResting = "0 0 0px 0px transparent";

  const sharedClasses = [
    "relative overflow-hidden inline-flex items-center justify-center transform-gpu will-change-transform",
    "rounded-full cursor-pointer outline-none border",
    "border-[var(--btn-border)]",
    "[-webkit-tap-highlight-color:transparent]",
    sz,
    className,
  ].join(" ");

  useEffect(() => {
    const btn = btnRef.current;
    const flair = flairRef.current;
    const labelEl = labelRef.current;

    const setFlairSize = () => {
      const { width, height } = btn.getBoundingClientRect();
      const diameter = Math.max(width, height) * 2.2;
      gsap.set(flair, {
        width: diameter,
        height: diameter,
        xPercent: -50,
        yPercent: -50,
        scale: 0,
        backgroundColor: flairColor,
      });
    };

    setFlairSize();
    gsap.set(labelEl, { color: textColor });
    gsap.set(btn, { "--btn-border": borderColor });

    const getPos = (e) => {
      const rect = btn.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };

    let activeTl = null;

    const onEnter = (e) => {
      const { x, y } = getPos(e);
      activeTl?.kill();
      gsap.set(flair, { left: x, top: y, scale: 0 });

      activeTl = gsap.timeline();

      // Slow, soft flair expansion — ease.inOut feels organic
      activeTl.to(flair, {
        scale: 1,
        duration: 0.55,
        ease: "power2.inOut",
      });

      activeTl.to(
        labelEl,
        { color: textHoverColor, duration: 0.35, ease: "power2.out" },
        0.1,
      );

      if (borderHoverColor)
        activeTl.to(
          btn,
          {
            "--btn-border": borderHoverColor,
            duration: 0.4,
            ease: "power2.out",
          },
          0,
        );

      if (shadowHover)
        activeTl.to(
          btn,
          { boxShadow: shadowHover, duration: 0.5, ease: "power2.out" },
          0,
        );

      activeTl.to(
        btn,
        {
          scale: 1.02,
          duration: 0.3,
          ease: "power2.out",
        },
        0,
      );
    };

    const onLeave = (e) => {
      const { x, y } = getPos(e);
      activeTl?.kill();
      gsap.set(flair, { left: x, top: y });

      activeTl = gsap.timeline();

      // Slightly slower retreat too — feels balanced
      activeTl.to(flair, {
        scale: 0,
        duration: 0.45,
        ease: "power2.inOut",
      });

      activeTl.to(
        labelEl,
        { color: textColor, duration: 0.25, ease: "power2.out" },
        0.3,
      );

      activeTl.to(
        btn,
        {
          scale: 1,
          duration: 0.25,
          ease: "power2.out",
        },
        0,
      );

      if (borderHoverColor)
        activeTl.to(
          btn,
          { "--btn-border": borderColor, duration: 0.35, ease: "power2.out" },
          0.3,
        );

      if (shadowHover)
        activeTl.to(
          btn,
          { boxShadow: shadowResting, duration: 0.45, ease: "power2.out" },
          0,
        );
    };

    btn.addEventListener("pointerenter", onEnter);
    btn.addEventListener("pointerleave", onLeave);
    window.addEventListener("resize", setFlairSize);

    return () => {
      btn.removeEventListener("pointerenter", onEnter);
      btn.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("resize", setFlairSize);
    };
  }, [
    flairColor,
    textColor,
    textHoverColor,
    shadowHover,
    borderColor,
    borderHoverColor,
  ]);

  const inner = (
    <>
      <span
        ref={flairRef}
        className="absolute rounded-full pointer-events-none"
      />
      <span
        ref={labelRef}
        className={[
          "relative z-10 inline-flex items-center gap-[inherit] pointer-events-none",
          "font-(family-name:--font-body) font-medium tracking-[0.01em] leading-none whitespace-nowrap",
        ].join(" ")}
      >
        {leftIcon && (
          <span className="inline-flex items-center text-[1.1em]">
            {leftIcon}
          </span>
        )}
        <span className={textTypo}>{label}</span>
        {rightIcon && (
          <span className="inline-flex items-center text-[1.1em]">
            {rightIcon}
          </span>
        )}
      </span>
    </>
  );

  if (href) {
    return (
      <Link
        ref={btnRef}
        href={href}
        target={target}
        rel={target === "_blank" ? "noopener noreferrer" : undefined}
        aria-label={ariaLabel || label}
        style={{ "--btn-border": borderColor, backgroundColor: bgColor }}
        className={sharedClasses}
      >
        {inner}
      </Link>
    );
  }

  return (
    <button
      ref={btnRef}
      onClick={onClick}
      aria-label={ariaLabel || label}
      style={{ "--btn-border": borderColor, backgroundColor: bgColor }}
      className={sharedClasses}
    >
      {inner}
    </button>
  );
}
