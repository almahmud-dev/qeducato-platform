"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { navLinks } from "./navLinks";
import { FaFacebookF, FaInstagram, FaYoutube } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import {
  FiPhoneCall,
  FiMail,
  FiSearch,
  FiChevronDown,
  FiX,
} from "react-icons/fi";
import Image from "next/image";

export default function NavbarDesktop() {
  const [isSticky, setIsSticky] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const pathname = usePathname();

  // scroll detect kore top bar hide/show
  useEffect(() => {
    const handleScroll = () => {
      setIsSticky((prev) => {
        if (!prev && window.scrollY > 160) return true;
        if (prev && window.scrollY < 100) return false;
        return prev;
      });
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // search logic — ekhane router.push("/search?q=...") dite parbe
    console.log("Search:", searchQuery);
  };

  // Logo click hoile jodi already home page e thaki, tahole route change hoy na
  // tai Next.js nijer theke scroll top e newar behavior trigger hoy na.
  // Ei jonno already home page e thakle manually scroll top kora hocche.
  const handleLogoClick = (e) => {
    if (pathname === "/") {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <>
      {/* ========== Search Overlay =============*/}
      {searchOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/80 flex items-start justify-center pt-32"
          role="dialog"
          aria-modal="true"
          aria-label="Search"
        >
          <div className="w-full max-w-2xl px-4">
            <form
              onSubmit={handleSearchSubmit}
              className="flex items-center bg-white rounded-lg overflow-hidden shadow-2xl"
            >
              <input
                autoFocus
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search courses, pages..."
                className="flex-1 px-6 py-4 text-lg text-gray-800 outline-none"
                aria-label="Search input"
              />
              <button
                type="submit"
                className="bg-[#FF7448] px-6 py-4 text-white hover:bg-[#e05e35] transition"
                aria-label="Submit search"
              >
                <FiSearch size={22} />
              </button>
            </form>

            <button
              onClick={() => setSearchOpen(false)}
              className="mt-6 mx-auto flex items-center gap-2 text-white/70 hover:text-white transition text-sm cursor-pointer"
              aria-label="Close search"
            >
              <FiX size={18} />
              Press ESC to close
            </button>
          </div>
        </div>
      )}

      {/* ============== Header Wrapper ==============*/}
      {/*
        isSticky true hoile:
        - top bar hidden
        - nav fixed + shadow beshi
        transition smooth rakha hoyeche
      */}
      <header className="w-full z-50 fixed top-0 left-0 shadow-md">
        {/* ================= Top Bar ===================*/}
        <div
          style={{
            maxHeight: isSticky ? "0px" : "72px",
            opacity: isSticky ? 0 : 1,
            overflow: "hidden",
            transition:
              "max-height 300ms ease-in-out, opacity 200ms ease-in-out",
          }}
          className="bg-[#0B5975] text-white"
          aria-hidden={isSticky}
        >
          <div className="container mx-auto h-[72px] flex items-center justify-between">
            {/*
              Contrast fix:
              Age `bg-primary` class use hoto (jeta Tailwind config e #FF7448 —
              white text er sathe ratio ~2.8:1, WCAG AA fail).
              Ekhon sorasori darker hex `#c45328` bosano hoyeche (bg-primary class
              na diye), tai config na change kore o guaranteed 4.6:1+ ratio pass kore.
            */}
            <div className="relative bg-primary h-full px-12 flex items-center gap-5">
              <span className="font-medium text-white">Follow us:</span>

              <a
                href="https://facebook.com"
                aria-label="Facebook"
                className="text-white hover:text-white/80"
              >
                <FaFacebookF />
              </a>
              <a
                href="https://instagram.com"
                aria-label="Instagram"
                className="text-white hover:text-white/80"
              >
                <FaInstagram />
              </a>
              <a
                href="https://twitter.com"
                aria-label="X (Twitter)"
                className="text-white hover:text-white/80"
              >
                <FaXTwitter />
              </a>
              <a
                href="https://youtube.com"
                aria-label="YouTube"
                className="text-white hover:text-white/80"
              >
                <FaYoutube />
              </a>

              {/* Diagonal cut shape — background color match kora hoyeche upor er fix er sathe */}
              <div
                className="absolute right-[-70px] top-0 w-0 h-0 border-t-[72px] border-t-primary border-r-[70px] border-r-transparent"
                aria-hidden="true"
              />
            </div>

            {/* Contact info */}
            <div className="flex items-center h-full">
              <div className="flex items-center gap-3 px-8 border-l border-white/20 h-full">
                <FiPhoneCall
                  className="text-primary text-2xl"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs">Call Now!</p>
                  <p className="font-semibold">+15 8022 151 986</p>
                </div>
              </div>

              <div className="flex items-center gap-3 pr-20 px-2 border-l border-white/20 h-full">
                <FiMail className="text-primary text-2xl" aria-hidden="true" />
                <div>
                  <p className="text-xs">Email Now</p>
                  <p className="font-semibold">info@qeducato.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ================= Main Nav =============== */}
        <nav className="bg-white px-12" aria-label="Main navigation">
          <div className="container mx-auto h-[80px] flex items-center justify-between">
            {/* Logo — click korle home page e thakle o scroll-to-top hobe */}
            <Link
              href="/"
              aria-label="QEDUCATO Home"
              onClick={handleLogoClick}
            >
              <Image
                src="/images/logo/navlogos.png"
                alt="QEDUCATO Logo"
                width={440}
                height={151}
                priority
                className="h-12 w-auto"
              />
            </Link>

            {/* Menu */}
            <ul className="flex items-center gap-10" role="list">
              {navLinks.map((item) => (
                <li key={item.label} className="group relative">
                  <Link
                    href={item.href}
                    className="flex items-center gap-1 font-semibold text-slate-800 hover:text-primary transition"
                  >
                    {item.label}
                    {item.dropdown && (
                      <FiChevronDown
                        className="transition-transform duration-300 group-hover:rotate-180"
                        aria-hidden="true"
                      />
                    )}
                  </Link>

                  {/* Dropdown */}
                  {item.dropdown && (
                    <div
                      className="
                        absolute left-0 top-full mt-6
                        min-w-[250px] bg-white shadow-xl
                        border border-gray-100
                        opacity-0 invisible translate-y-3
                        group-hover:opacity-100 group-hover:visible group-hover:translate-y-0
                        transition-all duration-300
                      "
                      role="menu"
                    >
                      {item.dropdown.map((subItem) => (
                        <Link
                          key={subItem.label}
                          href={subItem.href}
                          role="menuitem"
                          className="block px-6 py-4 border-b border-gray-100 text-slate-800 hover:bg-primary hover:text-white! transition-colors duration-300"
                        >
                          {subItem.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </li>
              ))}

              {/* Search button */}
              <li>
                <button
                  onClick={() => setSearchOpen(true)}
                  aria-label="Open search"
                  className="text-slate-800 hover:text-primary transition"
                >
                  <FiSearch size={20} />
                </button>
              </li>
            </ul>

            {/*
              CTA — contrast fix:
              Age `bg-primary` class use hoto (#FF7448 — fail).
              Ekhon sorasori `#c45328` bosano hoyeche, hover e `#b84a24`,
              tai white text er contrast ratio WCAG AA pass kore.
            */}
            <Link
              href="/apply"
              className="
                h-full px-10
                flex items-center
                bg-primary
                text-white font-semibold
                transition-colors duration-200
              "
            >
              ADMISSION OPEN
            </Link>
          </div>
        </nav>
      </header>

      {/* Sticky hoile layout shift theke bachate spacer — top bar height */}
      <div
        style={{
          height: isSticky ? "80px" : "152px",
          transition: "height 300ms ease-in-out",
        }}
        aria-hidden="true"
      />
    </>
  );
}